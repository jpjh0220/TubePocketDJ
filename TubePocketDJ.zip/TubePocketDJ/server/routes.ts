import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { spawn } from "child_process";
import path from "path";
import fs from "fs";
import { insertTrackSchema } from "@shared/schema";

const MUSIC_DIR = path.join(process.cwd(), "music");

// Ensure music directory exists
if (!fs.existsSync(MUSIC_DIR)) {
  fs.mkdirSync(MUSIC_DIR, { recursive: true });
}

// Helper to extract video ID from YouTube URL
function extractVideoId(url: string): string | null {
  const regex = /(?:v=|\/|youtu\.be\/)([0-9A-Za-z_-]{11})/;
  const match = url.match(regex);
  return match ? match[1] : null;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // GET /api/tracks - List all tracks
  app.get("/api/tracks", async (req, res) => {
    try {
      const tracks = await storage.getAllTracks();
      res.json(tracks);
    } catch (error) {
      console.error("Error fetching tracks:", error);
      res.status(500).json({ error: "Failed to fetch tracks" });
    }
  });

  // POST /api/download - Download a video
  app.post("/api/download", async (req, res) => {
    try {
      const { url } = req.body;
      
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }

      const videoId = extractVideoId(url);
      if (!videoId) {
        return res.status(400).json({ error: "Invalid YouTube URL" });
      }

      // Check if already exists
      const existing = await storage.getTrackByVideoId(videoId);
      if (existing) {
        return res.status(409).json({ 
          error: "Track already exists", 
          track: existing 
        });
      }

      // Create initial track entry
      const outputPath = path.join(MUSIC_DIR, `${videoId}.mp3`);
      const track = await storage.createTrack({
        videoId,
        title: `Downloading ${videoId}...`,
        channel: "YouTube",
        filePath: outputPath,
        status: "downloading",
        progress: 0,
      });

      // Start download in background using Python yt-dlp module (latest version)
      const ytdlp = spawn("python3", [
        "-m", "yt_dlp",
        "-x",
        "--audio-format", "mp3",
        "--audio-quality", "0",
        "-o", outputPath,
        "--print", "after_move:filepath",
        "--print", "title",
        "--print", "channel",
        url
      ]);

      let metadata: string[] = [];
      
      ytdlp.stdout.on("data", (data) => {
        const output = data.toString().trim();
        console.log(`yt-dlp output: ${output}`);
        metadata.push(output);
      });

      ytdlp.stderr.on("data", (data) => {
        console.log(`yt-dlp: ${data.toString()}`);
      });

      ytdlp.on("close", async (code) => {
        if (code === 0 && metadata.length >= 2) {
          // metadata[0] = filepath, metadata[1] = title, metadata[2] = channel
          const title = metadata[1] || `Track ${videoId}`;
          const channel = metadata[2] || "YouTube";
          
          await storage.updateTrackMetadata(videoId, title, channel);
          await storage.updateTrackStatus(videoId, "ready", 100);
          console.log(`Download complete: ${title}`);
        } else {
          await storage.updateTrackStatus(videoId, "error", 0);
          console.error(`Download failed with code ${code}`);
        }
      });

      res.json({ 
        message: "Download started", 
        track 
      });
    } catch (error) {
      console.error("Error starting download:", error);
      res.status(500).json({ error: "Failed to start download" });
    }
  });

  // GET /api/audio/:videoId - Serve audio file
  app.get("/api/audio/:videoId", async (req, res) => {
    try {
      const { videoId } = req.params;
      const track = await storage.getTrackByVideoId(videoId);
      
      if (!track) {
        return res.status(404).json({ error: "Track not found" });
      }

      if (track.status !== "ready") {
        return res.status(425).json({ error: "Track not ready yet" });
      }

      const filePath = track.filePath;
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: "Audio file not found" });
      }

      // Stream the audio file
      res.setHeader("Content-Type", "audio/mpeg");
      res.setHeader("Accept-Ranges", "bytes");
      
      const stat = fs.statSync(filePath);
      const fileSize = stat.size;
      const range = req.headers.range;

      if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
        const chunksize = (end - start) + 1;
        const file = fs.createReadStream(filePath, { start, end });
        
        res.writeHead(206, {
          "Content-Range": `bytes ${start}-${end}/${fileSize}`,
          "Content-Length": chunksize,
        });
        
        file.pipe(res);
      } else {
        res.writeHead(200, {
          "Content-Length": fileSize,
        });
        fs.createReadStream(filePath).pipe(res);
      }
    } catch (error) {
      console.error("Error serving audio:", error);
      res.status(500).json({ error: "Failed to serve audio" });
    }
  });

  return httpServer;
}
