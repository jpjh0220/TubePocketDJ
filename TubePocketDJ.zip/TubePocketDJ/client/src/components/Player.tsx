import { useEffect, useRef, useState } from 'react';
import { useMusicStore } from '../lib/store';
import { Play, Pause, SkipBack, SkipForward, Volume2, Maximize2, Mic2 } from 'lucide-react';

export function Player() {
  const { currentTrack, isPlaying, togglePlay, nextTrack, prevTrack } = useMusicStore();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(e => console.log("Autoplay prevented", e));
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentTrack]);

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const formatTime = (time: number) => {
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!currentTrack) {
    return (
      <div className="h-20 border-t border-border bg-card flex items-center justify-center text-muted-foreground font-mono text-xs uppercase tracking-widest">
        System_Idle // Waiting for playback
      </div>
    );
  }

  const audioUrl = `/api/audio/${currentTrack.videoId}`;

  return (
    <div className="h-20 border-t border-border bg-background flex flex-col relative group">
      {/* Progress Bar */}
      <div className="absolute top-[-1px] left-0 right-0 h-1 bg-secondary cursor-pointer group-hover:h-2 transition-all z-10">
        <div 
          className="h-full bg-primary relative" 
          style={{ width: `${(currentTime / duration) * 100}%` }}
        >
           <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-primary rounded-full shadow opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      </div>

      <div className="flex-1 flex items-center justify-between px-4 gap-4">
        {/* Info */}
        <div className="flex items-center gap-3 w-1/3">
          <div className="w-10 h-10 bg-primary/10 border border-primary/20 flex items-center justify-center">
            <div className={`w-1 h-4 bg-primary animate-pulse ${!isPlaying && 'animation-paused'}`} />
            <div className={`w-1 h-6 mx-0.5 bg-primary animate-pulse delay-75 ${!isPlaying && 'animation-paused'}`} />
            <div className={`w-1 h-3 bg-primary animate-pulse delay-150 ${!isPlaying && 'animation-paused'}`} />
          </div>
          <div className="min-w-0">
            <h4 className="text-sm font-bold text-foreground truncate font-mono">{currentTrack.title}</h4>
            <p className="text-xs text-muted-foreground truncate font-mono">{currentTrack.channel}</p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-4">
          <button onClick={prevTrack} className="text-muted-foreground hover:text-foreground transition-colors">
            <SkipBack className="w-5 h-5" />
          </button>
          
          <button 
            onClick={togglePlay}
            className="w-10 h-10 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current pl-0.5" />}
          </button>
          
          <button onClick={nextTrack} className="text-muted-foreground hover:text-foreground transition-colors">
            <SkipForward className="w-5 h-5" />
          </button>
        </div>

        {/* Extra & Volume */}
        <div className="flex items-center justify-end gap-4 w-1/3 text-muted-foreground">
          <span className="text-xs font-mono min-w-[80px] text-right">
            {formatTime(currentTime)} / {formatTime(duration)}
          </span>
          <Volume2 className="w-4 h-4 hover:text-foreground cursor-pointer" />
          <Maximize2 className="w-4 h-4 hover:text-foreground cursor-pointer" />
        </div>
      </div>

      <audio 
        ref={audioRef}
        src={audioUrl}
        onTimeUpdate={handleTimeUpdate}
        onEnded={nextTrack}
      />
    </div>
  );
}
