import { useEffect } from 'react';
import { useMusicStore } from '../lib/store';
import { Play, FileAudio, Music, Clock } from 'lucide-react';

export function Library() {
  const { library, playTrack, currentTrack, loadLibrary } = useMusicStore();

  // Load library on mount
  useEffect(() => {
    loadLibrary();
  }, [loadLibrary]);

  if (library.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-muted-foreground/40 font-mono text-xs border-l border-border">
        <div className="w-12 h-12 border border-border rounded mb-3 flex items-center justify-center">
          <FileAudio className="w-6 h-6" />
        </div>
        <p>LIBRARY_EMPTY</p>
        <p>INITIATE_DOWNLOADS_TO_POPULATE</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-background/50 border-l border-border custom-scrollbar">
      <div className="sticky top-0 bg-background/95 backdrop-blur p-3 border-b border-border z-10 flex justify-between items-center">
        <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-muted-foreground">
          Local_Storage ({library.length})
        </h2>
      </div>

      <div className="divide-y divide-border/50">
        {library.map((track) => {
          const isCurrent = currentTrack?.id === track.id;
          
          return (
            <div 
              key={track.id}
              className={`
                group relative p-3 hover:bg-card/50 transition-colors
                ${isCurrent ? 'bg-primary/5' : ''}
              `}
            >
              {/* Progress Bar Background for Downloading items */}
              {track.status === 'downloading' && (
                <div 
                  className="absolute bottom-0 left-0 h-[2px] bg-primary transition-all duration-300"
                  style={{ width: `${track.progress}%` }}
                />
              )}

              <div className="flex items-center gap-3">
                <div className="relative w-10 h-10 bg-secondary flex items-center justify-center shrink-0 border border-border overflow-hidden">
                  {track.status === 'downloading' ? (
                    <span className="text-[10px] font-mono text-primary">{Math.round(track.progress)}%</span>
                  ) : (
                    <Music className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  )}
                  
                  {track.status === 'ready' && (
                    <button 
                      onClick={() => playTrack(track)}
                      className="absolute inset-0 bg-primary/90 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                    >
                      <Play className="w-4 h-4 text-black fill-current" />
                    </button>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <h4 className={`text-sm font-medium truncate pr-2 font-mono ${isCurrent ? 'text-primary' : 'text-foreground'}`}>
                      {track.title}
                    </h4>
                    <span className="text-[10px] font-mono text-muted-foreground shrink-0 opacity-50">
                      {track.status === 'downloading' ? 'DL_ING' : 'MP3'}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate font-mono opacity-70">
                    {track.channel}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
