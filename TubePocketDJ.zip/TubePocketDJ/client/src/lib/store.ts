import { create } from 'zustand';

// Types
export interface SearchResult {
  id: string;
  title: string;
  channel: string;
  thumbnail: string;
  url: string;
}

export interface Track {
  id: number;
  videoId: string;
  title: string;
  channel: string;
  filePath: string;
  status: 'downloading' | 'processing' | 'ready' | 'error';
  progress: number;
  addedAt: string;
}

interface MusicStore {
  // Search State
  searchQuery: string;
  searchResults: SearchResult[];
  isSearching: boolean;
  setSearchQuery: (query: string) => void;
  performSearch: (apiKey: string) => Promise<void>;

  // Download/Library State
  library: Track[];
  loadLibrary: () => Promise<void>;
  addToLibrary: (url: string) => Promise<void>;
  
  // Player State
  currentTrack: Track | null;
  isPlaying: boolean;
  playTrack: (track: Track) => void;
  togglePlay: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
}

export const useMusicStore = create<MusicStore>((set, get) => ({
  // Search
  searchQuery: '',
  searchResults: [],
  isSearching: false,
  setSearchQuery: (query) => set({ searchQuery: query }),
  
  performSearch: async (apiKey) => {
    const { searchQuery } = get();
    if (!searchQuery.trim()) return;

    set({ isSearching: true });
    
    try {
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q=${encodeURIComponent(searchQuery)}&type=video&key=${apiKey}`
      );
      const data = await response.json();
      
      if (data.items) {
        const results: SearchResult[] = data.items.map((item: any) => ({
          id: item.id.videoId,
          title: item.snippet.title,
          channel: item.snippet.channelTitle,
          thumbnail: item.snippet.thumbnails.medium.url,
          url: `https://www.youtube.com/watch?v=${item.id.videoId}`
        }));
        set({ searchResults: results });
      }
    } catch (error) {
      console.error("Search failed", error);
    } finally {
      set({ isSearching: false });
    }
  },

  // Library - Real API calls
  library: [],
  
  loadLibrary: async () => {
    try {
      const response = await fetch('/api/tracks');
      const tracks = await response.json();
      set({ library: tracks });
    } catch (error) {
      console.error("Failed to load library:", error);
    }
  },
  
  addToLibrary: async (url) => {
    try {
      const response = await fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      
      if (response.status === 409) {
        // Duplicate
        const data = await response.json();
        console.log("Track already exists:", data.track);
        return;
      }
      
      if (!response.ok) {
        const error = await response.json();
        console.error("Download failed:", error);
        return;
      }
      
      // Reload library to get the new track
      await get().loadLibrary();
      
      // Poll for updates every 2 seconds
      const pollInterval = setInterval(async () => {
        await get().loadLibrary();
        
        // Stop polling if no tracks are downloading
        const hasDownloading = get().library.some(t => t.status === 'downloading');
        if (!hasDownloading) {
          clearInterval(pollInterval);
        }
      }, 2000);
      
    } catch (error) {
      console.error("Failed to add to library:", error);
    }
  },

  // Player
  currentTrack: null,
  isPlaying: false,
  playTrack: (track) => set({ currentTrack: track, isPlaying: true }),
  togglePlay: () => set(state => ({ isPlaying: !state.isPlaying })),
  nextTrack: () => {
    const { library, currentTrack } = get();
    if (!currentTrack) return;
    const currentIndex = library.findIndex(t => t.id === currentTrack.id);
    const nextTrack = library[currentIndex + 1];
    if (nextTrack && nextTrack.status === 'ready') set({ currentTrack: nextTrack, isPlaying: true });
  },
  prevTrack: () => {
    const { library, currentTrack } = get();
    if (!currentTrack) return;
    const currentIndex = library.findIndex(t => t.id === currentTrack.id);
    const prevTrack = library[currentIndex - 1];
    if (prevTrack && prevTrack.status === 'ready') set({ currentTrack: prevTrack, isPlaying: true });
  }
}));
