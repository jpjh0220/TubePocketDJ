import { SearchBar } from "@/components/SearchBar";
import { ResultList } from "@/components/ResultList";
import { CommandBar } from "@/components/CommandBar";
import { Library } from "@/components/Library";
import { Player } from "@/components/Player";

export default function Home() {
  return (
    <div className="flex flex-col h-screen bg-background text-foreground overflow-hidden font-sans selection:bg-primary selection:text-black">
      
      {/* Header / Status Bar */}
      <div className="h-8 bg-black border-b border-border flex items-center justify-between px-4 text-[10px] font-mono uppercase tracking-widest text-muted-foreground select-none">
        <div className="flex gap-4">
          <span className="text-primary">● SYSTEM_ONLINE</span>
          <span>MEM: 24%</span>
          <span>CPU: 12%</span>
        </div>
        <div>
          YT-DLP GUI v2.4.1 // RELEASE
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Panel: Search & Discovery */}
        <div className="w-1/2 flex flex-col border-r border-border bg-background/50">
          <div className="p-2 border-b border-border bg-muted/10">
            <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground pl-2 border-l-2 border-primary">
              Module: Discovery
            </h2>
          </div>
          <SearchBar />
          <ResultList />
        </div>

        {/* Right Panel: Terminal & Library */}
        <div className="w-1/2 flex flex-col bg-background/80 relative">
          {/* Decorative grid overlay */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,18,18,0)_1px,transparent_1px),linear-gradient(90deg,rgba(18,18,18,0)_1px,transparent_1px)] bg-[size:20px_20px] [mask-image:linear-gradient(to_bottom,white,transparent)] pointer-events-none opacity-20"></div>
          
          <div className="p-2 border-b border-border bg-muted/10 z-10">
            <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground pl-2 border-l-2 border-primary">
              Module: Acquisition & Storage
            </h2>
          </div>
          
          <div className="flex flex-col h-full z-10">
            <CommandBar />
            <Library />
          </div>
        </div>
      </div>

      {/* Footer Player */}
      <Player />
    </div>
  );
}
